# Vidpace Email Sender App

A simple SMTP-based email sender app.